import React, { useEffect } from 'react'
import { load_posts } from '../store/actions'
import { useDispatch, useSelector } from 'react-redux'

export const Posts = () => {

    const dispatch = useDispatch()

    const error = useSelector(state => state.isError)
    const loading = useSelector(state => state.loading)
    const posts = useSelector(state => state.posts)

    useEffect(() => {
        dispatch(load_posts())
    }, [])

    return <div>

        <h1>Posts</h1>
        {error && <b>Error: {error}</b>}
        {loading && <b>loading ...</b>}

        {
            posts.map((el, id) => {
                return <div key={id}>{el.title}</div>
            })
        }
    </div>
}