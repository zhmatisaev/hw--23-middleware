import React from "react";
import { Posts } from "./components/Posts";

function App() {
  return (
    <div style={{ textAlign: "center" }}>
      <Posts />
    </div>
  );
}

export default App;
